public enum Corps {
    Airforces,
    Marines
}
