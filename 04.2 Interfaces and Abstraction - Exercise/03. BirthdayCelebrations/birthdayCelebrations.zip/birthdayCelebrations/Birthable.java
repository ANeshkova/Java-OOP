package birthdayCelebrations;

public interface Birthable {
    public String getBirthDate();
}
