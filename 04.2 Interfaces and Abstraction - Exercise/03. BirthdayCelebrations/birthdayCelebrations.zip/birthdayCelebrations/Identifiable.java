package birthdayCelebrations;

public interface Identifiable {
    public String getId();
}
