package multipleImplementation;

public interface Person {
    public String getName();

    public int getAge();
}
