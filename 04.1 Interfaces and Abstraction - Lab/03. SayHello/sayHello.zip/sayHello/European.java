package sayHello;

public class European extends PersonImpl implements Person {

    protected European(String name) {
        super(name);
    }
}
