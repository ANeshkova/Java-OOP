package trafficLights;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;
}
